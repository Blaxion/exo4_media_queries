# Exercice 4 -> Media Queries

## - Pour des écrans plus grands que 1024px un carré qui fait 1/3 de l'écran en largeur, une couleur de fond blue, une bordure verte de 5px et la bordure est arrondie à 50%

## - Pour des écrans entre 600px et 1024px un carré qui fait 2/3 de l'écran en largeur, une couleur de fond rouge, une bordure jeune de 5px et la bordure est arrondie à 15px

## - Pour des écrans entre 320px et 600px un carré qui fait 3/3 de l'écran en largeur, une couleur de fond orange, une bordure noir de 5px